<div class="modal fade" id="modal_ver_detalle_inc" tabindex="" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                
                <img src="" alt="No hay imagen para mostrar" id="foto_detalle" class="img-fluid img-thumbnail">
            
            </div><!--Fin Modal Body--> 

            <div class="modal-footer">
                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-window-close fa-1x"></i>&nbsp;Cancelar</button>
                
            </div>           
            
        </div>
    </div>
</div>

