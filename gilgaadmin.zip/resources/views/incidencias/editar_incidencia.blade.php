
<div class="modal fade" id="editar_incidencia" tabindex="" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-lg modal-sm" role="document">
        <div class="modal-content">
            
            <div class="modal-header">
                <h5 class="modal-title"></h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            
            <div class="modal-body">
                
                <div class="container">        
                    <div class="row">            
                        <div class="col-md-12">                
                            <div class="card">
                                                    
                                <div class="card-body">
                                    {!!Form::open(array('action'=>'IncidenciasController@update','method'=>'POST','autocomplete'=>'off','enctype'=>'multipart/form-data'))!!}
                                    {{Form::token()}}
                                    <!--<form method="POST" action="{{url('incidencias')}}" enctype="multipart/form-data">-->
                                        @csrf
                                        <div class="form-group form-row">
                                            <div class="form-group col-md-4">
                                              <label for="tipo_solicitud">Tipo Solicitud</label>
                                              <input type="hidden" name="id" id="id" value="">
                                              <input type="text" class="form-control" id="tipo_solicitud" name="tipo_solicitud" readonly>
                                            </div>

                                            <div class="form-group col-md-4">
                                              <label for="prioridad">Prioridad</label>
                                              <input type="text" class="form-control" id="prioridad" name="prioridad" readonly>
                                              
                                            </div>
                                            <div class="form-group col-md-4">
                                                <label for="folio">Folio</label>
                                                <input type="text" class="form-control" id="folio" name="folio" readonly>
                                                                                  
                                            </div>
                                        </div>

                                        <div class="form-group form-row">

                                            
                                            <div class="form-group col-md-4">
                                              <label for="estacion">Estacion</label>
                                              <input type="text" class="form-control" id="estacion" name="estacion" placeholder="" readonly>
                                            </div>
                                            
                                            <div class="form-group col-md-4">
                                              <label for="id_area_estacion">Area Estacion</label>
                                              <select id="id_area_estacion" name="id_area_estacion" class="form-control" required>
                                                    
                                              </select>
                                            </div>
                                            
                                            <div class="form-group col-md-4">
                                              <label for="id_equipo">Equipo/SubArea</label>
                                              <select id="id_equipo" name="id_equipo" class="form-control" required>

                                              </select>
                                            </div>

                                        </div>

                                        <div class="form-group form-row">
                                            <div class="form-group col-md-4">
                                                <label for="posiciones">Posicion</label>
                                                <select id="posiciones" name="posiciones" class="form-control" disabled>
                                                </select>
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="refacciones">Refaccion</label>
                                                <select id="refacciones" name="refacciones" class="form-control" required>
                                                </select>
                                            </div>  

                                            <div class="form-group col-md-4">
                                                <label for="producto">Producto</label>
                                                <select id="producto" name="producto" class="form-control" disabled>
                                                </select>
                                            </div>                                                                                                      

                                        </div>

                                        <div class="form-group form-row">

                                            <div class="form-group col-md-4">
                                                <label for="asunto">Asunto</label>
                                                <input type="text" class="form-control" id="asunto" name="asunto" placeholder="Asunto..." required maxlength="50">
                                            </div>  

                                            <div class="form-group col-md-8">
                                                <label for="descripcion">Descripcion</label>
                                                <textarea style="overflow:auto;resize:none" class="form-control" rows="3" id="descripcion" name="descripcion" required maxlength="255"></textarea>
                                                
                                            </div>                               

                                        </div>

                                        <div class="form-group form-row">
                                            <div class="form-group col-md-4">
                                                <label for="foto_ruta">Actualizar foto</label>
                                                <input type="file" class="form-control" id="foto_ruta" name="foto_ruta">
                                                <input type="hidden" class="form-control" id="foto_ruta_escondida" name="foto_ruta_escondida">
                                            </div>

                                            <div class="form-group col-md-4">
                                                <label for="estatus_incidencia">Estatus</label>
                                                <input type="text" class="form-control" id="estatus_incidencia" name="estatus_incidencia" readonly>
                                            </div>
                                            
                                            <div class="form-group col-md-4">
                                                <label for="id_area_atencion">Area Atencion</label>
                                                <select id="id_area_atencion" name="id_area_atencion" class="form-control" required>
                                                </select>
                                            </div>

                                        </div>                           

                                        <div class="form-group form-row">
                                            <div class="ml-auto">
                                                <button type="button" class="btn btn-secondary" data-dismiss="modal"><i class="fas fa-window-close fa-1x"></i>&nbsp;Cancelar</button>
                                                <button type="submit" class="btn btn-primary"><i class="fas fa-edit fa-1x"></i>&nbsp;Actualizar Incidencia</button>
                                                
                                            </div>
                                        </div>                            

                                    <!--</form>-->
                                    {!!Form::close()!!}

                                </div>                    
                            </div>                
                        </div>            
                    </div>        
                </div>
            
            </div><!--Fin Modal Body-->            
            
        </div>
    </div>
</div>


