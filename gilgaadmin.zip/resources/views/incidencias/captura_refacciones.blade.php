@extends('layouts.app')

@section('content')

<div class="container">  
        
        <div class="row justify-content-center">            
            <div class="col-md-8">                
                <div class="card">
                    <div class="card-header">Agregar Nueva Refaccion</div>   
                    
                    <div class="card-body">
                        
                        {!!Form::open(array('action'=>'IncidenciasController@agregar_refaccion','method'=>'POST','autocomplete'=>'off','enctype'=>'multipart/form-data'))!!}
                        {{Form::token()}}
                        <!--<form method="POST" action="{{url('incidencias')}}" enctype="multipart/form-data">-->
                            @csrf
                            <div class="form-group form-row">
                                <div class="form-group col-md-4">
                                  <label for="tipo_solicitud">Tipo Solicitud</label>
                                  <select id="tipo_solicitud" class="form-control" name="tipo_solicitud">
                                    <option selected>incidencia</option>
                                    <option>requerimiento</option>
                                  </select>
                                </div>
                                
                                <div class="form-group col-md-4">
                                  <label for="prioridad">Prioridad</label>
                                  <!--<select id="prioridad" class="form-control" name="prioridad">
                                    <option selected>alta</option>
                                    <option>media</option>
                                    <option>baja</option>
                                  </select>-->
                                  <input type="text" class="form-control" id="prioridad" name="prioridad" required readonly>
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <label for="folio">Folio</label>
                                    <input type="text" class="form-control" id="folio" name="folio" required readonly>
                                    @if ($errors->has('folio'))
                                    <span class="invalid-feedback d-block" role="alert">
                                        <strong>{{ $errors->first('folio') }}</strong>
                                    </span>
                                    @endif
                                </div>
                            </div>
                            
                            <div class="form-group form-row">
                                
                                
                                <div class="form-group col-md-4">
                                  <label for="estacion">Estacion</label>
                                  <select id="estacion" name="estacion" class="form-control" required>
                                        <option value="*" selected>Todas</option>
                                        @foreach($estaciones as $estacion)
                                        <option value="{{$estacion->estacion}}">{{$estacion->estacion}}</option>
                                        @endforeach
                                    </select>
                                </div>
                                <!--<div class="form-group col-md-4">
                                    <label for="posicion">Posicion Equipo</label>
                                    <input type="text" class="form-control" id="posicion" name="posicion" required readonly>
                                </div>-->
                                
                                <div class="form-group col-md-4">
                                  <label for="id_area_estacion">Area Estacion</label>
                                  <select id="id_area_estacion" name="id_area_estacion" class="form-control" required>
                                      
                                  </select>
                                </div>
                                
                                <div class="form-group col-md-4">
                                  <label for="id_equipo">Equipo/SubArea</label>
                                  <select id="id_equipo" name="id_equipo" class="form-control" required>
                                      
                                  </select>
                                                                    
                                </div>
                                
                            </div>
                            
                            <div class="form-group form-row">
                                <div class="form-group col-md-4">
                                    <label for="posiciones">Posicion</label>
                                    <select id="posiciones" name="posiciones" class="form-control" disabled>
                                    </select>
                                </div>
                                
                                <div class="form-group col-md-4">
                                    <label for="refacciones">Refaccion</label>
                                    <select id="refacciones" name="refacciones" class="form-control" required>
                                    </select>
                                </div>  
                                
                                <div class="form-group col-md-4">
                                    <label for="producto">Producto</label>
                                    <select id="producto" name="producto" class="form-control" disabled>
                                    </select>
                                </div>                                                                                       
                                
                            </div>
                            
                            <div class="form-group form-row">
                                
                                <div class="form-group col-md-4">
                                    <label for="asunto">Asunto</label>
                                    <input type="text" class="form-control" id="asunto" name="asunto" placeholder="Asunto..." required maxlength="50">
                                   @if ($errors->has('asunto'))
                                   <span class="invalid-feedback d-block"  role="alert">
                                        <strong>{{ $errors->first('asunto') }}</strong>
                                   </span>
                                   @endif
                                    
                                </div>  
                                
                                <div class="form-group col-md-8">
                                    <label for="descripcion">Descripcion</label>
                                    <textarea style="overflow:auto;resize:none" class="form-control" rows="3" id="descripcion" name="descripcion" required maxlength="255"></textarea>
                                    @if ($errors->has('descripcion'))
                                   <span class="invalid-feedback d-block"  role="alert">
                                        <strong>{{ $errors->first('descripcion') }}</strong>
                                   </span>
                                   @endif
                                </div>                           
                                    
                                
                            </div>
                            
                                                       
                            
                            <div class="form-group form-row">
                                <div class=" ml-auto">
                                    
                                    
                                    <a href="/incidencias"><button type="button" class="btn btn-secondary"><i class="fas fa-window-close fa-1x"></i>&nbsp;Cancelar</button></a>
                                    <button type="submit" class="btn btn-primary"><i class="fas fa-plus-square fa-1x"></i>&nbsp;Agregar Refaccion</button>                                    
                                </div>
                            </div>                            
                            
                        <!--</form>-->
                        {!!Form::close()!!}
                        
                    </div>                    
                </div>                
            </div>            
        </div>        
    </div>





@endsection

@section('script')
@endsection