<?php

namespace App\Http\Controllers;

// import the Intervention Image Manager Class
use Intervention\Image\ImageManager;
use Image;

use App\Exports\UsersExport;
use App\Exports\IncidenciasExport;
use App\Exports\ComprasExport;
use Maatwebsite\Excel\Facades\Excel;

use Illuminate\Http\Response;
use Illuminate\Support\Facades\Storage;
use Illuminate\Support\Facades\File;
use Illuminate\Http\Request;
use App\Incidencia;
use App\DetalleIncidencia;
use App\Compras;
use App\Compra_Detalle;
use Illuminate\Support\Facades\Redirect;
use App\Http\Requests\IncidenciaFormRequest;
use App\IncidenciaLog;
use Illuminate\Support\Facades\DB;
use App\User;
use Illuminate\Support\Facades\Input;
//use DB;
use Carbon\Carbon;
//use Illuminate\Support\Facades\Response;
use Illuminate\Support\Collection;
use Auth;
use Illuminate\Support\Facades\Mail;
use Barryvdh\DomPDF\Facade as PDF;


class IncidenciasController extends Controller
{
    public function __construct()
    {
        $this->middleware('auth');
    }

    //metodo para guardar la nueva refaccion
    public function agregar_refaccion(){
        
    }

    //metodo que devuelve la vista para capturar refacciones
    public function vista_agregar_refaccion(){
        
        
        //cargo las estaciones a las que el usuario tiene permiso
        //Conseguir usuario identificado
        $user = \Auth::user();
        $id_usuario_permiso = $user->id;
        $estaciones = DB::table('usuarios_estaciones')
            ->where('id_usuario_permiso', '=', $id_usuario_permiso)->get();

        return view('incidencias.captura_refacciones', ["estaciones" => $estaciones]);
    }

    public function getCompras_detalle($id_compra){

        $compras_detalle = Compra_Detalle::where('id_compra','=',$id_compra)->get();
        return response()->json([
            'compras_detalle' => $compras_detalle
        ]);

    }

    public function getIncidencias_detalle($id_incidencia){
        
        $detalle_inc = DB::table('detalle_incidencias as det')
            ->select(DB::raw('u.name as usuario,det.fecha_detalle_incidencia,det.comentarios,IFNULL(det.foto_ruta,"") as foto_ruta,det.estatus'))
            ->join('users as u','det.id_usuario','=','u.id')
            ->where('det.id_incidencia',$id_incidencia)
            ->get();
        return response()->json(['detalle_inc' => $detalle_inc]);
        
    }

    public function rptordencompra($id_compra){
        $users = User::all();
        //$id_usuario_permiso = $user->id;
        
        $compras = DB::table('compras as c')
            ->select(DB::raw('c.id,c.id_incidencia as id_incidencia,c.id_usuario,c.fecha_compra,c.proveedor,c.facturar_a,c.folio,c.observaciones,c.usuario_autoriza,c.autorizada_sn,c.subtotal,c.iva,c.total,p.razon_social as proveedor_razon_social,com.razon_social as compania_razon_social'))    
            ->join('proveedores as p','c.proveedor','=','p.proveedor')
            ->join('companias as com','c.facturar_a','=','com.id')
            ->where('c.id','=',$id_compra)->get();          

        $compras_detalle = DB::table('compras_detalle')
            ->where('id_compra','=',$id_compra)->get();


        
        //var_dump($compras); 
        foreach($compras as $c){
            $id_inc = $c->id_incidencia;
            //break;
        } 

        //var_dump($id_inc);
                     
        $estacion_aux = DB::table('incidencias')->select('estacion')->where('id','=',$id_inc)->first();
        $estacion = DB::table('estaciones')->select(DB::raw('estacion,nombre_corto'))->where('estacion',$estacion_aux->estacion)->get();    
        
        $pdf = PDF::loadView('incidencias.reportes.orden_compra',compact('compras','compras_detalle','estacion','users'));
        return $pdf->stream();
        
    }
    
    public function reporte_incidencias() 
    {
        //cargo las estaciones a las que el usuario tiene permiso
        //Conseguir usuario identificado
        $user = \Auth::user();
        $id_usuario_permiso = $user->id;
        $estaciones = DB::table('usuarios_estaciones')
            ->where('id_usuario_permiso', '=', $id_usuario_permiso)->get();
        return view('incidencias.reporte_incidencias', ["estaciones" => $estaciones]);
    }
    
    public function genReporte(Request $request){
        
        //$incidencias = DB::table('incidencias')->get();
        //var_dump($incidencias);
        $estacion = $request->input('estacion');
        $fecha_desde = $request->input('fecha_desde');
        $fecha_hasta = $request->input('fecha_hasta');
        //var_dump($estacion);
        //var_dump($fecha_desde);
        //var_dump($fecha_hasta);
        
        return Excel::download(new IncidenciasExport($estacion,$fecha_desde,$fecha_hasta), 'ReporteIncidencias.xlsx');
    }



    public function reporte_compras() 
    {        
        return view('incidencias.reporte_compras');
    }
    
    public function genReporteCompras(Request $request){
        
        
        $fecha_desde = $request->input('fecha_desde');
        $fecha_hasta = $request->input('fecha_hasta');        
        
        return Excel::download(new ComprasExport($fecha_desde,$fecha_hasta), 'ReporteCompras.xlsx');
    }
    
    

    public function captura_incidencia()
    {
        return view('incidencias.captura_incidencia');
    }
    
    public function captura_detalle_incidencia($id)
    {
        $incidencia = Incidencia::findOrFail($id);        
        
        return view('incidencias.captura_detalle_incidencia')->with("incidencia", $incidencia);
        
    }
    
    //este metodo es para capturar el detalle_incidencia
    public function captura_detalleincidencia(Request $request, $id)
    {
        $incidencia = Incidencia::findOrFail($id);
        $detalleincidencia = new DetalleIncidencia;
        //var_dump($request);

        //Conseguir usuario identificado
        $user = \Auth::user();

        //Validacion del formulario
        $validate = $this->validate($request, [
            'comentarios' => 'required|string|max:255',
            'estatus' => 'required'
        ]);

        //$detalleincidencia->id_incidencia=$id_incidencia;
        $detalleincidencia->id_incidencia = $id;
        $detalleincidencia->id_usuario = $user->id;
        //$detalleincidencia->fecha_detalle_incidencia = $request->input('fecha_detalle');
        $fecha_det_inc = Carbon::now();
        $detalleincidencia->fecha_detalle_incidencia = $fecha_det_inc;
        $detalleincidencia->comentarios = $request->input('comentarios');

        //Subir la imagen
        $image_path = $request->file('foto_ruta');
        //var_dump($image_path);
        if ($image_path) {
            //poner nombre unico
            $image_path_name = time() . $image_path->getClientOriginalName();
            
            //definir ruta de guardado
            $ruta= storage_path('app/detalle_incidencias/'.$image_path_name);
            
            //reducir peso de imagen usando el parametro 60 de calidad de imagen 0-100
            Image::make($image_path->getRealPath())->resize(1280, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
              })->save($ruta,60);
              
            //Guardar en la carpeta storage/app/users
            //Storage::disk('detalle_incidencias')->put($image_path_name, File::get($image_path));

            //seteo el nombre de la imagen en el objeto
            $detalleincidencia->foto_ruta = $image_path_name;
            
        }
        
        $detalleincidencia->estatus = $request->input('estatus');
        $detalleincidencia->save();
        
        //despues de guardar el detalle debo actualizar el campo fecha_ultima_actualizacion de la tabla incidencias con la fecha del detalle
        $incidencia->fecha_ultima_actualizacion = $fecha_det_inc;
        $incidencia->update();
        
        //despues de Guardar el detalle_incidencia debo checar si el estatus = Terminado y el usuario que captura el detalle es igual
        //al creador de la incidencia, entonces debo hacer update a la incidencia y ponerle el estatus Cerrada
        if ($request->input('estatus') == "Terminado" && $incidencia->id_usuario == $user->id){
            //$incidencia = Incidencia::findOrFail($id);
            
            $incidencia->estatus_incidencia = "CERRADA";
            $incidencia->fecha_cierre = $fecha_det_inc;
            $incidencia->dias_vida_incidencia = $fecha_det_inc->diffInDays($incidencia->fecha_incidencia);
            $incidencia->update();
        }
        
        
        //return Redirect::action('IncidenciasController@show', array('id' => $id));

        return Redirect::to('incidencias/'.$id)->with('status', 'Detalle Generado Correctamente');
        //return redirect()->route('incidencias', ['id' => $id]);
        
        //return redirect()->action('IncidenciasController@show',['id' => $id])->with('status', 'Detalle Generado Correctamente');
        
    }
    
    public function incidencias_cerradas(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user();
        $role = $user->role;
        $id_usuario_permiso = $user->id;


        if ($role == 'admin') {
            if ($request) {
                $query = trim($request->get('searchText'));
                $incidencias_cerradas = DB::table('incidencias')
                    //->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,incidencias.fecha_incidencia,incidencias.id_area_estacion,incidencias.id_equipo,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion'))
                    ->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,estaciones.nombre_corto,estaciones.zona,incidencias.fecha_incidencia,incidencias.id_area_estacion,areas_estacion.descripcion as area_estacion_descripcion,incidencias.id_equipo,equipos.descripcion as equipo_descripcion,refacciones.descripcion as refaccion_descripcion,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,areas_atencion.descripcion as area_atencion_descripcion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion,incidencias.posicion'))    
                    ->join('estaciones','incidencias.estacion','=','estaciones.estacion')    
                    ->join('usuarios_estaciones', 'incidencias.estacion', '=', 'usuarios_estaciones.estacion')
                    ->join('encargados_areas_atencion', 'incidencias.id_area_atencion', '=', 'encargados_areas_atencion.id_area_atencion')
                    ->join('areas_atencion','incidencias.id_area_atencion','=','areas_atencion.id')
                    ->join('areas_estacion', function($join){
                        $join->on('incidencias.id_area_estacion','=','areas_estacion.id');
                        $join->on('incidencias.estacion','=','areas_estacion.estacion');
                    })    
                    ->join('equipos', function($join){
                        $join->on('incidencias.id_equipo','=','equipos.id');
                        $join->on('incidencias.estacion','=','equipos.estacion');
                    })
                    ->join('refacciones', function($join){
                        $join->on('incidencias.id_refaccion','=','refacciones.id');
                        $join->on('incidencias.estacion','=','refacciones.estacion');
                        $join->on('incidencias.id_equipo','=','refacciones.id_equipo');
                    })    
                    //->where('incidencias.estacion', 'like', '%' . $query . '%')
                    ->where('incidencias.estatus_incidencia', '=', 'CERRADA')
                    ->where('encargados_areas_atencion.id_usuario','=',$id_usuario_permiso)
                    ->where('usuarios_estaciones.id_usuario_permiso', '=', $id_usuario_permiso)        
                    ->orderBy('incidencias.estacion')
                    ->orderBy('incidencias.fecha_incidencia')
                    ->orderBy('incidencias.prioridad')
                    //->paginate(20);
                    ->get();
                $users = User::all();
                return view('incidencias.incidencias_cerradas', ["incidencias_cerradas" => $incidencias_cerradas, "searchText" => $query, "users" => $users]);
            }
        } else {
            if ($request) {
                $query = trim($request->get('searchText'));
                $incidencias_cerradas = DB::table('incidencias')
                    //->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,incidencias.fecha_incidencia,incidencias.id_area_estacion,incidencias.id_equipo,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion'))
                    ->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,estaciones.nombre_corto,estaciones.zona,incidencias.fecha_incidencia,incidencias.id_area_estacion,areas_estacion.descripcion as area_estacion_descripcion,incidencias.id_equipo,equipos.descripcion as equipo_descripcion,refacciones.descripcion as refaccion_descripcion,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,areas_atencion.descripcion as area_atencion_descripcion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion,incidencias.posicion'))    
                    ->join('estaciones','incidencias.estacion','=','estaciones.estacion')    
                    ->join('usuarios_estaciones', 'incidencias.estacion', '=', 'usuarios_estaciones.estacion')
                    ->join('areas_atencion','incidencias.id_area_atencion','=','areas_atencion.id')    
                    ->join('areas_estacion', function($join){
                        $join->on('incidencias.id_area_estacion','=','areas_estacion.id');
                        $join->on('incidencias.estacion','=','areas_estacion.estacion');
                    })    
                    ->join('equipos', function($join){
                        $join->on('incidencias.id_equipo','=','equipos.id');
                        $join->on('incidencias.estacion','=','equipos.estacion');
                    })
                    ->join('refacciones', function($join){
                        $join->on('incidencias.id_refaccion','=','refacciones.id');
                        $join->on('incidencias.estacion','=','refacciones.estacion');
                        $join->on('incidencias.id_equipo','=','refacciones.id_equipo');
                    })    
                    ->where('usuarios_estaciones.id_usuario_permiso', '=', $id_usuario_permiso)
                    //->where('incidencias.estatus_incidencia', 'like', '%' . $query . '%')
                    ->where('incidencias.estatus_incidencia', '=', 'CERRADA')
                    ->orderBy('incidencias.estacion')
                    ->orderBy('incidencias.fecha_incidencia')
                    ->orderBy('incidencias.prioridad')
                    //->paginate(20);
                    ->get();    
                $users = User::all();
                return view('incidencias.incidencias_cerradas', ["incidencias_cerradas" => $incidencias_cerradas, "searchText" => $query, "users" => $users]);
            }
        }
    }
    
        
    //metodo para cargar solo incidencias por una determinada estacion desde el clic de home.blade de la grafica circular
    public function incidenciasxestacion(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user();
        $role = $user->role;
        $id_usuario_permiso = $user->id;
        
        if ($role == 'admin') {
            if ($request) {
                //$query = trim($request->get('searchText'));
                $incidencias = DB::table('incidencias')
                    //->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,incidencias.fecha_incidencia,incidencias.id_area_estacion,incidencias.id_equipo,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion'))
                    ->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,estaciones.nombre_corto,estaciones.zona,incidencias.fecha_incidencia,incidencias.id_area_estacion,areas_estacion.descripcion as area_estacion_descripcion,incidencias.id_equipo,equipos.descripcion as equipo_descripcion,refacciones.descripcion as refaccion_descripcion,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,areas_atencion.descripcion as area_atencion_descripcion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion,incidencias.posicion'))    
                    ->join('estaciones','incidencias.estacion','=','estaciones.estacion')    
                    ->join('usuarios_estaciones', 'incidencias.estacion', '=', 'usuarios_estaciones.estacion')
                    ->join('encargados_areas_atencion', 'incidencias.id_area_atencion', '=', 'encargados_areas_atencion.id_area_atencion')
                    ->join('areas_atencion','incidencias.id_area_atencion','=','areas_atencion.id')
                    ->join('areas_estacion', function($join){
                        $join->on('incidencias.id_area_estacion','=','areas_estacion.id');
                        $join->on('incidencias.estacion','=','areas_estacion.estacion');
                    })    
                    ->join('equipos', function($join){
                        $join->on('incidencias.id_equipo','=','equipos.id');
                        $join->on('incidencias.estacion','=','equipos.estacion');
                    })
                    ->join('refacciones', function($join){
                        $join->on('incidencias.id_refaccion','=','refacciones.id');
                        $join->on('incidencias.estacion','=','refacciones.estacion');
                        $join->on('incidencias.id_equipo','=','refacciones.id_equipo');
                    })    
                    //->where('incidencias.estacion', 'like', '%' . $query . '%')
                    ->where('incidencias.estatus_incidencia', '=', 'ABIERTA')
                    ->where('encargados_areas_atencion.id_usuario','=',$id_usuario_permiso)
                    ->where('incidencias.estacion','=',$request->estacion)
                    ->where('usuarios_estaciones.id_usuario_permiso', '=', $id_usuario_permiso)        
                    ->orderBy('incidencias.estacion')
                    ->orderBy('incidencias.fecha_incidencia')
                    ->orderBy('incidencias.prioridad')
                    ->get();  
                    //->paginate(20);
                $users = User::all();
                return view('incidencias.incidencias_x_estacion', ["incidencias" => $incidencias,  "users" => $users]);
            }
        }
        
        
    }
    
    //este metodo carga el listado de incidencias en la vista index.blade
    public function index(Request $request)
    {
        //Conseguir usuario identificado
        $user = \Auth::user();
        $role = $user->role;
        $id_usuario_permiso = $user->id;


        if ($role == 'admin') {
            if ($request) {
                $query = trim($request->get('searchText'));
                $incidencias = DB::table('incidencias')
                    ->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,estaciones.nombre_corto,estaciones.zona,incidencias.fecha_incidencia,incidencias.id_area_estacion,areas_estacion.descripcion as area_estacion_descripcion,incidencias.id_equipo,equipos.descripcion as equipo_descripcion,refacciones.descripcion as refaccion_descripcion,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,areas_atencion.descripcion as area_atencion_descripcion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion,incidencias.posicion'))
                    ->join('estaciones','incidencias.estacion','=','estaciones.estacion')    
                    ->join('usuarios_estaciones', 'incidencias.estacion', '=', 'usuarios_estaciones.estacion')
                    ->join('encargados_areas_atencion', 'incidencias.id_area_atencion', '=', 'encargados_areas_atencion.id_area_atencion')
                    ->join('areas_atencion','incidencias.id_area_atencion','=','areas_atencion.id')
                    ->join('areas_estacion', function($join){
                        $join->on('incidencias.id_area_estacion','=','areas_estacion.id');
                        $join->on('incidencias.estacion','=','areas_estacion.estacion');
                    })    
                    ->join('equipos', function($join){
                        $join->on('incidencias.id_equipo','=','equipos.id');
                        $join->on('incidencias.estacion','=','equipos.estacion');
                    })
                    ->join('refacciones', function($join){
                        $join->on('incidencias.id_refaccion','=','refacciones.id');
                        $join->on('incidencias.estacion','=','refacciones.estacion');
                        $join->on('incidencias.id_equipo','=','refacciones.id_equipo');
                    })
                    //->where('incidencias.estacion', 'like', '%' . $query . '%')
                    ->where('incidencias.estatus_incidencia', '=', 'ABIERTA')
                    ->where('encargados_areas_atencion.id_usuario','=',$id_usuario_permiso)
                    ->where('usuarios_estaciones.id_usuario_permiso', '=', $id_usuario_permiso)        
                    ->orderBy('incidencias.estacion')
                    ->orderBy('incidencias.fecha_incidencia')
                    ->orderBy('incidencias.prioridad')
                    ->get();  
                    //->paginate(20);
                $users = User::all();
                return view('incidencias.index', ["incidencias" => $incidencias, "searchText" => $query, "users" => $users]);
            }
        } else {
            if ($request) {
                $query = trim($request->get('searchText'));
                $incidencias = DB::table('incidencias')
                    ->select(DB::raw('incidencias.id,incidencias.id_usuario,incidencias.created_at,incidencias.updated_at,incidencias.folio,incidencias.estacion,estaciones.nombre_corto,estaciones.zona,incidencias.fecha_incidencia,incidencias.id_area_estacion,areas_estacion.descripcion as area_estacion_descripcion,incidencias.id_equipo,equipos.descripcion as equipo_descripcion,refacciones.descripcion as refaccion_descripcion,incidencias.asunto,incidencias.descripcion,incidencias.id_area_atencion,areas_atencion.descripcion as area_atencion_descripcion,incidencias.foto_ruta,incidencias.estatus_incidencia,incidencias.tipo_solicitud,incidencias.prioridad,incidencias.fecha_ultima_actualizacion,incidencias.fecha_cierre,incidencias.dias_vida_incidencia,areas_atencion.descripcion as area_atencion_descripcion,incidencias.posicion'))
                    ->join('estaciones','incidencias.estacion','=','estaciones.estacion')    
                    ->join('usuarios_estaciones', 'incidencias.estacion', '=', 'usuarios_estaciones.estacion')
                    ->join('areas_atencion','incidencias.id_area_atencion','=','areas_atencion.id')
                    ->join('areas_estacion', function($join){
                        $join->on('incidencias.id_area_estacion','=','areas_estacion.id');
                        $join->on('incidencias.estacion','=','areas_estacion.estacion');
                    })    
                    ->join('equipos', function($join){
                        $join->on('incidencias.id_equipo','=','equipos.id');
                        $join->on('incidencias.estacion','=','equipos.estacion');
                    })
                    ->join('refacciones', function($join){
                        $join->on('incidencias.id_refaccion','=','refacciones.id');
                        $join->on('incidencias.estacion','=','refacciones.estacion');
                        $join->on('incidencias.id_equipo','=','refacciones.id_equipo');
                    })
                    ->where('usuarios_estaciones.id_usuario_permiso', '=', $id_usuario_permiso)
                    //->where('incidencias.estatus_incidencia', 'like', '%' . $query . '%')
                    ->where('incidencias.estatus_incidencia', '=', 'ABIERTA')
                    ->orderBy('incidencias.estacion')
                    ->orderBy('incidencias.fecha_incidencia')
                    ->orderBy('incidencias.prioridad')
                    ->get();                      
                    //->paginate(20);
                $users = User::all();
                return view('incidencias.index', ["incidencias" => $incidencias, "searchText" => $query, "users" => $users]);
            }
        }
    }

    //este metodo carga la vista captura_incidencia.blade
    public function create()
    {
        //cargo las estaciones a las que el usuario tiene permiso
        //Conseguir usuario identificado
        $user = \Auth::user();
        $id_usuario_permiso = $user->id;
        $estaciones = DB::table('usuarios_estaciones')
            ->where('id_usuario_permiso', '=', $id_usuario_permiso)->get();
        
                
        $refacciones_estacion = DB::table('refacciones')
            ->select(DB::raw('areas_estacion.descripcion as area,equipos.descripcion as Equipo,refacciones.id,refacciones.estacion,refacciones.descripcion,refacciones.prioridad,refacciones.posicion'))    
            ->join('equipos', function($join){
                        $join->on('refacciones.id_equipo','=','equipos.id');
                        $join->on('refacciones.estacion','=','equipos.estacion');
                    })  
            ->join('areas_estacion', function($join){
                        $join->on('equipos.id_area_estacion','=','areas_estacion.id');
                        $join->on('equipos.estacion','=','areas_estacion.estacion');
                    })        
            ->where('refacciones.estacion','=','6620')
            ->orderBy('refacciones.id_equipo')
            ->orderBy('refacciones.id')->get();            

        //Debo cargar las areas de cada estacion, segun la estacion que estoy seleccionando
        /*foreach($estaciones as $est){
            $miestacion = $est->estacion;
            break;
        }*/
        //var_dump($miestacion);

        /*$areas_estacion = DB::table('areas_estacion')
                ->select('areas_estacion.id','areas_estacion.descripcion')
                ->join('usuarios_estaciones','areas_estacion.estacion','=','usuarios_estaciones.estacion')
                ->where('areas_estacion.estacion','=',$miestacion)->get();*/

        return view('incidencias.captura_incidencia', ["estaciones" => $estaciones, "refacciones_estacion" => $refacciones_estacion]);
    }
    
    //este metodo es para autorizar la compra cambiando de NO a SI en la columna autorizada_sn de la tabla compras
    public function aut_compra(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user(); 
        
        $compras = Compras::findOrFail($request->id_compra);
        $compras->autorizada_sn = "SI";
        $compras->usuario_autoriza = $user->id;
        $compras->update();
        //return redirect()->action('IncidenciasController@show',['id' => $request->id_incidencia])->with('status', 'Compra autorizada correctamente');
        return redirect()->action('IncidenciasController@show',$request->id_incidencia)->with('status', 'Compra autorizada correctamente');
    }

    //este metodo es para denegar la compra cambiando de SI a NO en la columna autorizada_sn de la tabla compras
    public function denegar_compra(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user(); 
        
        $compras = Compras::findOrFail($request->den_id_compra);
        $compras->autorizada_sn = "NO";
        $compras->usuario_autoriza = $user->id;
        $compras->update();
        //return redirect()->action('IncidenciasController@show',['id' => $request->den_id_incidencia])->with('status', 'Compra denegada correctamente');
        return redirect()->action('IncidenciasController@show',$request->den_id_incidencia)->with('status', 'Compra denegada correctamente');
    }

    //este metodo es para cerrar la compra cambiando de NO a SI en la columna cerrada_sn de la tabla compras
    public function cerrar_compra(Request $request){
        //Conseguir usuario identificado
        $user = \Auth::user(); 
        
        $compras = Compras::findOrFail($request->cerrar_id_compra);
        $compras->cerrada_sn = "SI";
        
        $compras->update();
        //return redirect()->action('IncidenciasController@show',['id' => $request->cerrar_id_incidencia])->with('status', 'Compra cerrada correctamente');
        return redirect()->action('IncidenciasController@show',$request->cerrar_id_incidencia)->with('status', 'Compra cerrada correctamente');
    }

    public function eliminar_compra(Request $request){
        $id_incidencia = $request->del_id_incidencia;
        try {
            DB::beginTransaction();

            //primero debo borrar los detalles de la compra
            $del_detalles = Compra_Detalle::where('id_compra','=',$request->del_id_compra)->delete();

            //ahora si, procedo a borrar la compra
            $del_compra = Compras::find($request->del_id_compra);
            $del_compra->delete();


            DB::commit();

        } catch (\Exception $e) {
            var_dump($e);
            DB::rollBack();
        }
        //return redirect()->action('IncidenciasController@show',['id' => $id_incidencia])->with('status', 'Compra eliminada correctamente');       
        return redirect()->action('IncidenciasController@show',$id_incidencia)->with('status', 'Compra eliminada correctamente');       
    }

    public function editar_compra(Request $request){
        $compra = Compras::findOrFail($request->edit_id);

        //Conseguir usuario identificado
        $user = \Auth::user();        
        
        //Validacion del formulario
        
        
        $id_incidencia = $request->input('edit_id_incidencia');

        try {
            DB::beginTransaction();           
            
            
            $compra->id_usuario = $user->id;                  
            
            $compra->observaciones = $request->input('edit_observaciones');                     

            $compra->subtotal = $request->input('edit_subtotal');
            $compra->iva = $request->input('edit_iva');
            $compra->total = $request->input('edit_total_final');  
            
            $compra->update(); 
            
            //debo eliminar todos los detalles de la compra en la bd para posteriormente guardar los nuevos detalles
            $delete = Compra_Detalle::where('id_compra','=',$request->edit_id)->delete();
            
            //despues de guardar en compras, debo guardar en compras_detalle 
            //ARRAY DE CONTROLES           
            $id_incidencia_detalle = $request->input('edit_id_incidencia_detalle');            
            $cantidad = $request->input('edit_cantidad');
            $unidad = $request->input('edit_unidad');        
            $producto_descripcion = $request->input('edit_producto_descripcion');

            $tipo_cambio = $request->input('edit_tipo_cambio');
            $moneda = $request->input('edit_moneda');

            $precio_unitario = $request->input('edit_precio_unitario');
            $total = $request->input('edit_total');
           
            $cont = 0;
            while($cont < count($cantidad)){
                $compra_detalle = new Compra_Detalle();
                $compra_detalle->id_compra = $compra->id;
                $compra_detalle->id_incidencia = $id_incidencia_detalle[$cont];               
                $compra_detalle->cantidad = $cantidad[$cont];
                $compra_detalle->unidad = $unidad[$cont];
                $compra_detalle->producto_descripcion = $producto_descripcion[$cont];

                $compra_detalle->tipo_cambio = $tipo_cambio[$cont];
                $compra_detalle->moneda = $moneda[$cont];

                $compra_detalle->precio_unitario = $precio_unitario[$cont];
                $compra_detalle->total = $total[$cont];
                
                $compra_detalle->save();
                $cont = $cont + 1;
            }


            DB::commit();

        } catch (\Exception $e) {
            //var_dump($e);
            DB::rollBack();
        }        
        
        //return redirect()->action('IncidenciasController@show',['id' => $id_incidencia])->with('status', 'Compra editada correctamente');
        return redirect()->action('IncidenciasController@show',$id_incidencia)->with('status', 'Compra editada correctamente');


    }
    
    public function alta_compras(Request $request)
    {
                
        //Conseguir usuario identificado
        $user = \Auth::user();        
        
        //Validacion del formulario
       /* $validate = $this->validate($request, [
            'observaciones' => 'string|max:255',
            'proveedor' => 'int',            
            'facturar_a' => 'required',
            'folio' => 'string|max:10',
            'cantidad' => 'required|int',
            'unidad' => 'string|max:5',
            'producto_descripcion' => 'required|string|max:255',
            'precio_unitario' => 'required',
            'total' => 'required',
            'entregar_en' => 'required|string|max:15'
        ]); */
        
        /*Obtengo el folio*/ 
        $max_folio_db = DB::table('compras')
            ->select(DB::raw('max(convert(folio,unsigned integer)) max_folio '))                
            ->first();
        
        $max_folio = $max_folio_db->max_folio;
        
        if ($max_folio == null){
            $max_folio = 0;
        }        
        $OUTfolio = $max_folio+1;
        
        try {
            DB::beginTransaction();
            $compras = new Compras;
            $id_incidencia = $request->id_incidencia;

            $compras->id_incidencia = $id_incidencia;
            $compras->id_usuario = $user->id;
            //$detalleincidencia->fecha_detalle_incidencia = $request->input('fecha_detalle');
            $fecha_compra = Carbon::now();
            $compras->fecha_compra = $fecha_compra;
            
            $compras->proveedor = $request->input('proveedor'); //Catalogo proveedores
            $compras->facturar_a = $request->input('facturar_a'); //catalogo companias
            
            $compras->folio = $OUTfolio;        
            
            $compras->observaciones = $request->input('observaciones');
            //$compras->usuario_autoriza = 1;//$request->input('usuario_autoriza'); //Catalogo users            
            $compras->autorizada_sn = 'NO';//$request->input('autorizada_sn');
            $compras->cerrada_sn = 'NO';             

            $compras->subtotal = $request->input('subtotal');
            $compras->iva = $request->input('iva');
            $compras->total = $request->input('total_final');  
            
            $compras->save();               
            
            //despues de guardar en compras, debo guardar en compras_detalle 
            //ARRAY DE CONTROLES           
            $id_incidencia_detalle = $request->input('id_incidencia_detalle');            
            $cantidad = $request->input('cantidad');
            $unidad = $request->input('unidad');        
            $producto_descripcion = $request->input('producto_descripcion');

            $tipo_cambio = $request->input('tipo_cambio');
            $moneda = $request->input('moneda');

            $precio_unitario = $request->input('precio_unitario');
            $total = $request->input('total');
           
            $cont = 0;
            while($cont < count($cantidad)){
                $compra_detalle = new Compra_Detalle();
                $compra_detalle->id_compra = $compras->id;
                $compra_detalle->id_incidencia = $id_incidencia_detalle[$cont];               
                $compra_detalle->cantidad = $cantidad[$cont];
                $compra_detalle->unidad = $unidad[$cont];
                $compra_detalle->producto_descripcion = $producto_descripcion[$cont];

                $compra_detalle->tipo_cambio = $tipo_cambio[$cont];
                $compra_detalle->moneda = $moneda[$cont];

                $compra_detalle->precio_unitario = $precio_unitario[$cont];
                $compra_detalle->total = $total[$cont];
                
                $compra_detalle->save();
                $cont = $cont + 1;
            }


            DB::commit();

        } catch (\Exception $e) {
            //var_dump($e);
            DB::rollBack();
        }        
        
        //return redirect()->action('IncidenciasController@show',['id' => $id_incidencia])->with('status', 'Compra solicitada correctamente');
        return redirect()->action('IncidenciasController@show',$id_incidencia)->with('status', 'Compra solicitada correctamente');
    }

    //este metodo guarda la incidencia
    public function store(Request $request)
    {
        $incidencia = new Incidencia;
        //var_dump($request);

        //Conseguir usuario identificado
        $user = \Auth::user();
        $id = $user->id;

        //Validacion del formulario
        $validate = $this->validate($request, [
            'folio' => 'required|string|max:10',
            'asunto' => 'required|string|max:50',
            'descripcion' => 'required|string|max:255'
        ]);

        $incidencia->id_usuario = $id;
        $incidencia->folio = $request->input('folio');
        $incidencia->estacion = $request->input('estacion');
        //$incidencia->fecha_incidencia = $request->input('fecha'); //Carbon::now();
        $incidencia->fecha_incidencia = Carbon::now();
        $incidencia->id_area_estacion = $request->input('id_area_estacion');
        $incidencia->id_equipo = $request->input('id_equipo');
        //var_dump($request->input('id_equipo'));
        //$incidencia->id_equipo = 1;
        $incidencia->asunto = $request->input('asunto');
        $incidencia->descripcion = $request->input('descripcion');
        $incidencia->id_area_atencion = $request->input('id_area_atencion');

        //Subir la imagen
        $image_path = $request->file('foto_ruta');
        //var_dump($image_path);
        if ($image_path) {
            //poner nombre unico                       
            $image_path_name = time().$image_path->getClientOriginalName();
            
            //definir ruta de guardado
            $ruta= storage_path('app/incidencias/'.$image_path_name);
            
            //reducir peso de imagen usando el parametro 60 de calidad de imagen 0-100
            //Image::make($image_path->getRealPath())->save($ruta,60);
            //
            Image::make($image_path->getRealPath())->resize(1280, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
              })->save($ruta,60);
            //var_dump($img);

            //Guardar en la carpeta storage/app/incidencias
            //Storage::disk('incidencias')->put($image_path_name, File::get($image_path));
            

            //seteo el nombre de la imagen en el objeto
            $incidencia->foto_ruta = $image_path_name;
        }
        //$incidencia->foto_ruta=$request->input('foto_ruta');

        $incidencia->estatus_incidencia = $request->input('estatus_incidencia');
        $incidencia->tipo_solicitud = $request->input('tipo_solicitud');
        $incidencia->prioridad = $request->input('prioridad');
        
        $incidencia->posicion = $request->input('posiciones');
        $incidencia->producto = $request->input('producto');
        $incidencia->id_refaccion = $request->input('refacciones');
        
        $incidencia->save();
        return Redirect::to('incidencias')->with(['message' => 'Incidencia Generada Correctamente']);
    }
    
    //este metodo llena la vista show.blade con los detalles_incidencia
    public function show($id)
    {
        
        //Conseguir usuario identificado
        $user = \Auth::user();
        $id_usuario_permiso = $user->id;
        
        $detalles = DB::table('detalle_incidencias')
            ->where('id_incidencia', '=', $id)
            ->paginate(20);
        $log = IncidenciaLog::where("id_incidencia", $id)->paginate(20);
        $users = User::all();
        $proveedores = DB::table('proveedores')->get();
        $companias = DB::table('companias')->get();


        /*$compras_detalle = DB::table('compras_detalle')
            ->select('id_compra')
            ->where('id_incidencia', '=', $id)
            ->get();

        $id_compra = $id_compra_aux->id_compra;    
        
        $compras = DB::table('compras')            
            ->where('id', '=', $id_compra)
            ->paginate(20);*/

        $compras = DB::table('compras_detalle as cd')
                    ->select(DB::raw('c.*'))
                    ->join('compras as c', function($join){
                        $join->on('cd.id_compra','=','c.id');
                    })
                    ->where('cd.id_incidencia','=',$id)
                    ->paginate(20);   
                      
        //var_dump($compras);
        $permisos = DB::table('permisos')
            ->where('usuario_permiso','=',$id_usuario_permiso)
            ->get();

        $estacion_aux = DB::table('incidencias')->select('estacion')->where('id','=',$id)->first();
        $estacion = $estacion_aux->estacion;

        $compras_incidencias = DB::table('incidencias as i')
            ->select(DB::raw('concat(i.id,"-",i.estacion,"-",r.descripcion) as incidencia,i.id'))    
                ->join('refacciones as r', function($join){
                    $join->on('i.id_refaccion','=','r.id');
                    $join->on('i.estacion','=','r.estacion');
                    $join->on('i.id_equipo','=','r.id_equipo');
                })
            ->where('i.estatus_incidencia', '=', 'ABIERTA')
            ->where('i.estacion','=',$estacion)
            ->get();    

        return view("incidencias.show", ["detalles" => $detalles, "id_incidencia" => $id, "log" => $log, "users" => $users,"proveedores" => $proveedores,"companias" => $companias,"compras" => $compras,"permisos" => $permisos,"compras_incidencias" => $compras_incidencias]);
    }

    public function edit($id)
    {
        return view("incidencias.edit", ["incidencia" => Incidencia::findOrFail($id)]);
    }
    
    public function updateDetalleIncidencia(Request $request){
        $detalle_inc = DetalleIncidencia::findOrFail($request->id);
        
        $detalle_inc->comentarios = $request->get('comentarios');
        $detalle_inc->estatus = $request->get('estatus');
        
        $id = $detalle_inc->id_incidencia;
        //Subir la imagen
        $image_path = $request->file('foto_ruta');
        if ($image_path) {
            //poner nombre unico
            $image_path_name = time() . $image_path->getClientOriginalName();
            
            //definir ruta de guardado
            $ruta= storage_path('app/detalle_incidencias/'.$image_path_name);
            
            //reducir peso de imagen usando el parametro 60 de calidad de imagen 0-100
            //Image::make($image_path->getRealPath())->save($ruta,60);
            Image::make($image_path->getRealPath())->resize(1280, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
              })->save($ruta,60);

            //Guardar en la carpeta storage/app/users
            //Storage::disk('detalle_incidencias')->put($image_path_name, File::get($image_path));

            //seteo el nombre de la imagen en el objeto
            $detalle_inc->foto_ruta = $image_path_name;
            
        }
        $detalle_inc->update();
        //return Redirect::to('incidencias');
        //return redirect()->action('IncidenciasController@show',['id' => $id])->with('status', 'Detalle Actualizado Correctamente');
        return redirect()->action('IncidenciasController@show',$id)->with('status', 'Detalle Actualizado Correctamente');
    }

    public function update(Request $request/*, $id*/)
    {
        $incidencia = Incidencia::findOrFail($request->id);
        //$incidencia->id_usuario=$request->get('id_usuario');
        //$incidencia->folio=$request->get('folio');
        //$incidencia->estacion=$request->get('estacion');
        //$incidencia->fecha_incidencia=$request->get('fecha_incidencia');
        $incidencia->id_area_estacion = $request->get('id_area_estacion');
        $incidencia->id_equipo = $request->get('id_equipo');
        $incidencia->asunto = $request->get('asunto');
        $incidencia->descripcion = $request->get('descripcion');
        $incidencia->id_area_atencion = $request->get('id_area_atencion');
        
        //$incidencia->foto_ruta = $request->get('foto_ruta');
        //Subir la imagen
        $image_path = $request->file('foto_ruta');
        //var_dump($image_path);
        if ($image_path) {
            //poner nombre unico
            $image_path_name = time() . $image_path->getClientOriginalName();
            
            //definir ruta de guardado
            $ruta= storage_path('app/incidencias/'.$image_path_name);
            
            //reducir peso de imagen usando el parametro 60 de calidad de imagen 0-100
            //Image::make($image_path->getRealPath())->save($ruta,60);
            Image::make($image_path->getRealPath())->resize(1280, null, function ($constraint) {
                $constraint->aspectRatio();
                $constraint->upsize();
              })->save($ruta,60);

            //Guardar en la carpeta storage/app/users
            //Storage::disk('incidencias')->put($image_path_name, File::get($image_path));

            //seteo el nombre de la imagen en el objeto
            $incidencia->foto_ruta = $image_path_name;
        }
        
        $incidencia->estatus_incidencia = $request->get('estatus_incidencia');
        $incidencia->tipo_solicitud = $request->get('tipo_solicitud');
        $incidencia->prioridad = $request->get('prioridad');
        
        $incidencia->posicion = $request->input('posiciones');
        $incidencia->producto = $request->input('producto');
        $incidencia->id_refaccion = $request->input('refacciones');
        
        $incidencia->update();
        return Redirect::to('incidencias');
    }

    public function obtenerFolio(Request $request)
    {
        //$folio = DB::select('call obtenerFolioInicidencia (?,?,@OUTfolio)',array($request->estacion,$request->tipo_solicitud));
        //$folio = DB::select("call obtenerFolioInicidencia(?,?,@OUTfolio)",array("6620","incidencia"));
        //$folio = DB::select("call obtenerFolioInicidencia('6620','incidencia',@OUTfolio)");
        
        //hosting mexico no acepta procedimientos almacenados ¬¬ asi que debo cambiar a querys normales
        //$folio = DB::select('call obtenerFolioInicidencia(?,?)', array("6620", "incidencia"));
        
        $max_folio_db = DB::table('incidencias')
                ->select(DB::raw('max(convert(substring(folio,5),unsigned integer)) max_folio '))
                ->where('estacion','=',$request->estacion)
                ->where('tipo_solicitud','=',$request->tipo_solicitud)
                ->first();
        
        $max_folio = $max_folio_db->max_folio;
        
        if ($max_folio == null){
            $max_folio = 0;
        }
        //var_dump($max_folio);
        $OUTfolio = substr($request->tipo_solicitud,0,3).'-'.strval($max_folio+1);
        //var_dump($OUTfolio);
        
        //return response()->json($max_folio);
        return response($OUTfolio);
    }

    public function obtenerAreas(Request $request)
    {
        /*return $areas_estacion = DB::table('areas_estacion')
                ->select('areas_estacion.id','areas_estacion.descripcion')
                ->join('usuarios_estaciones','areas_estacion.estacion','=','usuarios_estaciones.estacion')
                ->where('areas_estacion.estacion','=',$estacion)->get();
        return Incidencia::where('estacion',$estacion)->get();*/
        //var_dump($request);
        if ($request->ajax()) {
            $estaciones = DB::table('areas_estacion')->where('estacion', '=', $request->estacion)->get();
            return response()->json($estaciones);
        }
    }

    public function obtenerEquipos(Request $request)
    {

        if ($request->ajax()) {
            $equipos = DB::table('equipos')
                ->where('estacion', '=', $request->estacion)
                ->where('id_area_estacion', '=', $request->id_area_estacion)
                ->get();
            return response()->json($equipos);
        }
    }
    
    public function obtenerDetalleEquipo(Request $request){
        if ($request->ajax()){
            $equipo = DB::table('equipos')
                ->where('id', '=', $request->id_equipo)
                ->get();
            return response()->json($equipo);
        }
    }
    
    public function obtenerPosiciones(Request $request){
        if ($request->ajax()){
            $posiciones = DB::table('posiciones')
                ->where('id_equipo', '=', $request->id_equipo)
                ->where('estacion', '=', $request->estacion)
                ->get();
            return response()->json($posiciones);
        }
    }
    
    public function obtenerRefacciones(Request $request){
        if ($request->ajax()){
            $refacciones = DB::table('refacciones')
                ->where('id_equipo', '=', $request->id_equipo)
                ->where('estacion', '=', $request->estacion)
                ->where('posicion', '=', $request->posicion)    
                ->get();
            return response()->json($refacciones);
        }
    }
    
    //Este metodo carga el catalogo de refacciones
    public function obtenerCatalogoRefacciones(Request $request){
        if ($request->ajax()){
            
            $refacciones_estacion = DB::table('refacciones')
            ->select(DB::raw('equipos.descripcion as Equipo,refacciones.id,refacciones.estacion,refacciones.descripcion,refacciones.prioridad,refacciones.posicion'))    
            ->join('equipos', function($join){
                        $join->on('refacciones.id_equipo','=','equipos.id');
                        $join->on('refacciones.estacion','=','equipos.estacion');
                    })    
            ->where('refacciones.estacion','=','6620')
            ->orderBy('refacciones.id_equipo')
            ->orderBy('refacciones.id')->get();
            
           
            return response()->json($refacciones_estacion);
            
        }
    }
    
    public function obtenerRefaccionesDetalle(Request $request){
        if ($request->ajax()){
            $refaccionesDetalle = DB::table('refacciones')
                ->where('id_equipo', '=', $request->id_equipo)
                ->where('estacion', '=', $request->estacion)
                ->where('posicion', '=', $request->posicion) 
                ->where('id', '=', $request->id_refaccion)    
                ->get();
            return response()->json($refaccionesDetalle);
        }
    }
    
    public function obtenerRefaccionesSinPosicion(Request $request){
        if ($request->ajax()){
            $RefaccionesSinPosicion = DB::table('refacciones')
                ->where('id_equipo', '=', $request->id_equipo)
                ->where('estacion', '=', $request->estacion)                    
                ->get();
            return response()->json($RefaccionesSinPosicion);
        }
    }
    
    public function obtenerProductos(Request $request){
        if ($request->ajax()){
            $productos = DB::table('productos_estaciones')                
                ->where('estacion', '=', $request->estacion)                    
                ->get();
            return response()->json($productos);
        }
    }

    public function obtenerAreasAtencion(Request $request)
    {
        //var_dump($request->id);
        if ($request->ajax()) {
            $areas_atencion = DB::table('areas_atencion')
                ->where('id', '=', $request->id)
                ->get();
            return response()->json($areas_atencion);
        }
    }
    

    public function destroy()
    { }

    public function getImage($filename)
    {
        $file = Storage::disk('incidencias')->get($filename);
        return new Response($file, 200);
    }
    
    public function getImageDetalleIncidencias($filename)
    {
        $file = Storage::disk('detalle_incidencias')->get($filename);
        return new Response($file, 200);
    }

    public function imagenDetalleIncidencias($filename){
        $file = Storage::disk('detalle_incidencias')->get($filename);

        return new Response($file, 200);
    }

    public function descargarImagenDetalleIncidencias($filename){
        //definir ruta de guardado
        $ruta= storage_path('app/detalle_incidencias/'.$filename);
        return response()->download($ruta);
    }

    public function status_change($id)
    {
        $incidencia = Incidencia::where("id", $id)->first();

        if (!$incidencia) {
            return response()->json([
                'status' => 'error',
                'code' => '200',
                'message' => 'No existe la incidencia.',
            ], 200);
        }

        $user = Auth::user();

        if ($user->id != $incidencia->id_usuario) {
            $log = IncidenciaLog::where([["id_usuario", $user->id], ["id_incidencia", $id]])->first();

            if (!$log) {
                IncidenciaLog::create([
                    'id_usuario' => $user->id,
                    'id_incidencia' => $id,
                    'estatus' => "VISTO"
                ]);

                return response()->json([
                    'status' => 'success',
                    'code' => '200',
                    'message' => 'Registro de visualización creado correctamente.',
                ], 200);
            }
        }
    }

    
}
