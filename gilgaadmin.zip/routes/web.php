<?php

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider within a group which
| contains the "web" middleware group. Now create something great!
|
*/

Route::get('/', function () {
    return view('welcome');
});

Auth::routes();

Route::get('/', 'HomeController@index')->name('home');
Route::resource('/incidencias', 'IncidenciasController');

//ruta para ver el listado de incidencias_cerradas
Route::get('/incidencias_cerradas', 'IncidenciasController@incidencias_cerradas');

Route::get('/incidencia/imagenes/{filename}','IncidenciasController@getImage')->name('incidencia.imagenes');
Route::get('/incidencia/detalleimagenes/{filename}','IncidenciasController@getImageDetalleIncidencias')->name('incidencia.detalleimagenes');

Route::get('/incidencias/detalles/imagenes/{filename}','IncidenciasController@imagenDetalleIncidencias')->name('imagenDetalleIncidencias');

Route::get('/incidencias_cerradas/detalles/descargaimagenes/{filename}','IncidenciasController@descargarImagenDetalleIncidencias')->name('descargarImagenDetalleIncidencias');

//Route::get('/incidencias/detalle/captura','IncidenciasController@captura_detalle_incidencia')->name('detalle');

//No es necesario cambiar la URL en estos casos, con que se cambie el método alcanza.
//esta ruta es usada en show.blade.php aqui se llama a la vista de CREAR DETALLE
Route::get('/incidencia/{id}/detalle/captura','IncidenciasController@captura_detalle_incidencia')->name('detalle');

//esta ruta se usa para guardar en detalle_incidencia
Route::post('/incidencia/{id}/detalle/captura','IncidenciasController@captura_detalleincidencia')->name('detalle_send');

Route::post('/incidencia/actualizar','IncidenciasController@update')->name('detalle_actualizar');
Route::post('/incidencia/actualizar_detalle','IncidenciasController@updateDetalleIncidencia')->name('detalle_incidencia_actualizar');

//rutas para Compras
Route::post('/incidencia/alta_compras','IncidenciasController@alta_compras')->name('alta_compras');
Route::post('/incidencia/editar_compra','IncidenciasController@editar_compra')->name('editar_compra');
Route::post('/incidencia/eliminar_compra','IncidenciasController@eliminar_compra')->name('eliminar_compra');

//esta ruta es usada para guardar en incidencias_logs
Route::post('/incidencia/{id}/status/change','IncidenciasController@status_change')->name('status_change');

//Ruta para obtener los detalles de la compra
Route::get('/incidencias/compras_detalle/{id_compra}','IncidenciasController@getCompras_detalle')->name('getCompras_detalle');

//Ruta para obtener los detalles de la incidencia
Route::get('/incidencias_cerradas/detalles/{id_incidencia}','IncidenciasController@getIncidencias_detalle')->name('getIncidencias_detalle');

//esta ruta es usada para autorizar una compra
//Route::get('/incidencia/compras/{id}/change','IncidenciasController@aut_compra')->name('aut_compra');
Route::post('/incidencia/compras/change','IncidenciasController@aut_compra')->name('aut_compra');
Route::post('/incidencia/compras/denegar','IncidenciasController@denegar_compra')->name('denegar_compra');
Route::post('/incidencia/compras/cerrar','IncidenciasController@cerrar_compra')->name('cerrar_compra');


//Route::get('/incidencias/captura_incidencia', 'IncidenciasController@captura_incidencia')->name('captura_incidencia');
Route::get('areas','IncidenciasController@obtenerAreas');
Route::get('equipos','IncidenciasController@obtenerEquipos');
Route::get('equipo_detalle','IncidenciasController@obtenerDetalleEquipo');
Route::get('areas_atencion','IncidenciasController@obtenerAreasAtencion');

Route::get('folios','IncidenciasController@obtenerFolio');

Route::get('posiciones','IncidenciasController@obtenerPosiciones');
Route::get('refacciones','IncidenciasController@obtenerRefacciones');
Route::get('catalogo_refacciones','IncidenciasController@obtenerCatalogoRefacciones');
Route::get('productos_estaciones','IncidenciasController@obtenerProductos');
Route::get('refacciones_detalle','IncidenciasController@obtenerRefaccionesDetalle');
Route::get('refaccionesSinPosicion','IncidenciasController@obtenerRefaccionesSinPosicion');
Route::get('/incidencias2','IncidenciasController@orderByEstacion');

Route::get('incidencias/estacion/{estacion}','IncidenciasController@incidenciasxestacion');

//Route::get('users/export/', 'IncidenciasController@export');

//ruta para ver el reporte de incidencias
Route::get('/reporte_incidencias', 'IncidenciasController@reporte_incidencias');

Route::post('/reporte_incidencias/generar_reporte', 'IncidenciasController@genReporte');

//Rutas para reporte compras
Route::get('/reporte_compras', 'IncidenciasController@reporte_compras')->name('viewReporteCompras');
Route::post('/reporte_compras/generar_reporte', 'IncidenciasController@genReporteCompras')->name('genReporteCompras');

Route::get('/incidencias/pdf/rptordencompra/{id_compra}','IncidenciasController@rptordencompra')->name('rptordencompra');



//Rutas para catalogo de refacciones
Route::get('/catalogos/refacciones/agregar', 'IncidenciasController@vista_agregar_refaccion')->name('vista_agregar_refaccion');
Route::post('/catalogos/refacciones/agregar_refaccion', 'IncidenciasController@agregar_refaccion')->name('agregar_refaccion');